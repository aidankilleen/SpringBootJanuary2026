package ie.rc.SpringBootTemplatedWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootTemplatedWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
