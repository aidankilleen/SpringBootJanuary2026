package ie.rc.SpringBootTemplatedWebApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootTemplatedWebAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootTemplatedWebAppApplication.class, args);
	}

}
