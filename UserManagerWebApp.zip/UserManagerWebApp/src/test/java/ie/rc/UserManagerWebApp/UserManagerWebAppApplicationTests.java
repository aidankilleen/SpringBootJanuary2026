package ie.rc.UserManagerWebApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserManagerWebAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
