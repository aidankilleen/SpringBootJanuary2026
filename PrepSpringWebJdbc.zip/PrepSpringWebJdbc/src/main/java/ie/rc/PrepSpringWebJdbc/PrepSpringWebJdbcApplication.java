package ie.rc.PrepSpringWebJdbc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PrepSpringWebJdbcApplication {

	public static void main(String[] args) {
		SpringApplication.run(PrepSpringWebJdbcApplication.class, args);
	}

}
